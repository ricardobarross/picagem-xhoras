# Picagem X€Horas — Arquitetura

Web App de Gestão de Ponto e Calculadora de Salário Líquido.

Stack: Next.js (App Router) + TypeScript + Tailwind CSS + shadcn/ui + Supabase (Auth, Postgres, RLS).

## Árvore de ficheiros recomendada

```
├── app/
│   ├── (auth)/
│   │   ├── layout.tsx
│   │   ├── login/page.tsx
│   │   └── cadastro/page.tsx
│   ├── (app)/                          # rotas protegidas (ver middleware.ts)
│   │   ├── layout.tsx                  # shell com navegação/sidebar
│   │   ├── dashboard/page.tsx          # cards + resumo de vencimento
│   │   ├── ponto/page.tsx              # TimeTracker (picagem em tempo real)
│   │   ├── registos/page.tsx           # calendário + tabela editável
│   │   ├── relatorios/page.tsx         # exportação PDF/CSV
│   │   └── configuracoes/
│   │       ├── page.tsx
│   │       ├── perfil/page.tsx
│   │       ├── remuneracao/page.tsx     # valores por hora
│   │       ├── subsidios/page.tsx
│   │       └── impostos/page.tsx
│   ├── auth/callback/route.ts          # callback OAuth (Google)
│   ├── api/
│   │   ├── time-entries/route.ts
│   │   └── export/{pdf,csv}/route.ts
│   ├── layout.tsx
│   └── globals.css
├── components/
│   ├── ui/                             # shadcn/ui
│   ├── time-tracker/
│   │   ├── TimeTracker.tsx             # ✅ incluído nesta entrega
│   │   ├── ManualEntryForm.tsx
│   │   ├── TimeEntriesTable.tsx
│   │   └── MonthCalendar.tsx
│   ├── dashboard/
│   │   ├── SummaryCards.tsx
│   │   └── PayslipSimulation.tsx
│   └── settings/
│       ├── HourlyRatesForm.tsx
│       ├── BenefitsForm.tsx
│       └── TaxRulesForm.tsx
├── lib/
│   ├── supabase/
│   │   ├── client.ts                   # ✅ incluído
│   │   ├── server.ts                   # ✅ incluído
│   │   └── middleware.ts               # ✅ incluído
│   ├── salary-calculator.ts            # ✅ incluído — motor de cálculo
│   ├── time-utils.ts                   # ✅ incluído — funções auxiliares
│   ├── export/{pdf-generator,csv-generator}.ts
│   └── validations/*.schema.ts         # zod
├── types/
│   └── database.types.ts               # ✅ incluído
├── hooks/
│   ├── useTimeTracker.ts
│   └── useSalaryCalculation.ts
├── middleware.ts                       # ✅ incluído
└── supabase/
    └── migrations/0001_init.sql        # ✅ incluído — schema completo
```

## Fórmula do cálculo financeiro (resumo)

1. **Horas por turno** = (saída − entrada) − pausa.
2. **Classificação**: turnos em dias normais que excedem o limiar diário
   (`overtime_daily_threshold_hours`) geram horas extra em 2 escalões
   (`overtime_tier1_percentage`, `overtime_tier2_percentage`); turnos em
   sábado/domingo/feriado usam a totalidade das horas à taxa desse dia.
   O adicional noturno é calculado à parte, por sobreposição com a janela
   configurada (`night_shift_start_time`/`end_time`), e SOMADO como prémio
   — não substitui a categoria do dia.
3. **Rendimento bruto** = Σ(horas de cada categoria × taxa respetiva) +
   subsídio de alimentação + duodécimos de férias/Natal + subsídio de
   transporte.
4. **Base tributável**: cada rubrica é marcada como tributável ou isenta
   (ex.: subsídio de alimentação até ao limite legal é isento por defeito).
5. **Descontos**: Segurança Social = base tributável × taxa configurada;
   IRS = taxa fixa OU escalão aplicável (tabela `irs_tax_brackets`) sobre
   (base tributável − Segurança Social).
6. **Líquido** = Bruto total (tributável + isento) − Segurança Social − IRS.

Implementação completa em `lib/salary-calculator.ts`.

## Evolução para equipas (fase 2)

O schema atual é 1 utilizador = 1 conjunto de dados, isolado por RLS
(`auth.uid() = user_id`). Para comercializar para uma equipa, o passo
seguinte é acrescentar `organizations` + `organization_members` e um
`organization_id` opcional em `time_entries`/`user_settings`, sem migrar
dados existentes (ver comentário no fim de `0001_init.sql`).

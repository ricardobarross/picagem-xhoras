// types/database.types.ts
// Tipos manuais alinhados com supabase/migrations/0001_init.sql.
// Em produção, substituir/gerar via:
//   npx supabase gen types typescript --project-id <id> > types/database.types.ts

export type RateType = 'fixed' | 'percentage';
export type PaymentMethod = 'card' | 'cash';
export type BonusPaymentType = 'lump_sum' | 'monthly_installments';
export type TransportFrequency = 'daily' | 'monthly';
export type PaidBy = 'employee' | 'employer';
export type IrsCalculationType = 'fixed_rate' | 'bracket';
export type DayType = 'normal' | 'saturday' | 'sunday' | 'holiday';
export type EntryStatus = 'in_progress' | 'completed';
export type EntrySource = 'clock' | 'manual';

export interface Profile {
  id: string;
  full_name: string | null;
  job_title: string | null;
  company_name: string | null;
  avatar_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface UserSettings {
  id: string;
  user_id: string;

  base_hourly_rate: number;

  saturday_rate_type: RateType;
  saturday_rate_value: number;
  sunday_rate_type: RateType;
  sunday_rate_value: number;
  holiday_rate_type: RateType;
  holiday_rate_value: number;
  night_shift_rate_type: RateType;
  night_shift_rate_value: number;
  night_shift_start_time: string; // "HH:MM:SS"
  night_shift_end_time: string;

  overtime_daily_threshold_hours: number;
  overtime_tier1_percentage: number;
  overtime_tier1_max_hours: number;
  overtime_tier2_percentage: number;

  meal_allowance_daily_value: number;
  meal_allowance_payment_method: PaymentMethod;
  meal_allowance_taxable: boolean;

  bonus_payment_type: BonusPaymentType;
  bonus_lump_sum_month: number | null;

  transport_allowance_value: number;
  transport_allowance_frequency: TransportFrequency;

  health_insurance_value: number;
  health_insurance_paid_by: PaidBy;

  social_security_rate: number;
  irs_calculation_type: IrsCalculationType;
  irs_fixed_rate: number;

  currency: string;
  created_at: string;
  updated_at: string;
}

export interface IrsTaxBracket {
  id: string;
  user_settings_id: string;
  min_income: number;
  max_income: number | null;
  rate: number;
  deduction: number;
  created_at: string;
}

export interface TimeEntry {
  id: string;
  user_id: string;
  entry_date: string; // "YYYY-MM-DD"
  clock_in: string | null; // ISO timestamptz
  break_start: string | null;
  break_end: string | null;
  clock_out: string | null;
  day_type: DayType;
  night_shift_override: boolean | null;
  status: EntryStatus;
  source: EntrySource;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

// Estrutura mínima esperada pelo @supabase/ssr createClient<Database>()
export interface Database {
  public: {
    Tables: {
      profiles: { Row: Profile; Insert: Partial<Profile> & { id: string }; Update: Partial<Profile> };
      user_settings: { Row: UserSettings; Insert: Partial<UserSettings> & { user_id: string }; Update: Partial<UserSettings> };
      irs_tax_brackets: { Row: IrsTaxBracket; Insert: Partial<IrsTaxBracket>; Update: Partial<IrsTaxBracket> };
      time_entries: { Row: TimeEntry; Insert: Partial<TimeEntry> & { user_id: string; entry_date: string }; Update: Partial<TimeEntry> };
    };
  };
}
